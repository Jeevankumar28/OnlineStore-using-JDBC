package com.training.pojo;

	public class Item{
		private String itemname;
		private String Category;
		private double buyingPrice;
		public String getItemname() {
			return itemname;
		}
		public void setItemname(String itemname) {
			this.itemname = itemname;
		}
		public String getCategory() {
			return Category;
		}
		public void setCategory(String category) {
			Category = category;
		}
		public double getBuyingPrice() {
			return buyingPrice;
		}
		public void setBuyingPrice(double buyingPrice) {
			this.buyingPrice = buyingPrice;
		}
		
	}


